# Conseil des IA

Six familles via OpenRouter Free. Une question commune par jour pendant sept jours à partir de la date de Paris configurée. Chaque famille propose une thèse et répond ensuite aux autres. Le dernier jour reprend les répliques archivées des six premiers jours. Au maximum 12 appels par séance, 84 sur sept jours, plus 6 pour le test technique à lancer une fois avant le début.

## Installation

1. Créer un dépôt public dédié et initialisé.
2. Ajouter `debate.py`, `config.json`, `test_debate.py` et ce README à la racine. Créer `.github/workflows/debate.yml` avec le contenu du fichier du même nom. Utiliser la branche par défaut.
3. Dans Actions, sélectionner Conseil des IA, Run workflow, mode `check`. Les tests à blanc ne contactent aucune API et n'archivent aucune transcription.
4. Créer une clé OpenRouter avec un compte Free sans crédit ni moyen de paiement. Dans le dépôt, Settings → Secrets and variables → Actions → Secrets → New repository secret. Nom `OPENROUTER_API_KEY`, valeur la clé. Ne placer la clé dans aucun fichier.
5. Exécuter le workflow en mode `smoke`. Il faut un résultat `ok` pour les six familles avant de fixer le départ. Ce test n'est pas archivé comme débat.
6. Dans Settings → Secrets and variables → Actions → Variables → New repository variable, créer `CONSEIL_START_DATE` au format AAAA-MM-JJ. Pour un départ aujourd'hui, lancer manuellement le mode `debate`. Sans action manuelle, GitHub tente la séance chaque jour à 17 h 17 UTC puis à 20 h 17 UTC. Les déclenchements peuvent être retardés ou manqués. Jours 1 à 7 inclus selon l'heure de Paris. Une séance déjà archivée n'est pas rejouée. Pour arrêter la campagne, supprimer la variable de départ.
7. Vérifier le premier run dans Actions et le dossier `data` sur la branche par défaut. Les transcriptions et le tableau de couverture seront publics.

Le workflow est limité aux runners standard d'un dépôt public. L'API est limitée aux modèles explicitement `:free`, vérifiés dans le catalogue et appelés avec des plafonds à zéro. Un modèle retiré du catalogue bloque la séance. Un échec pendant la séance est consigné. Aucun modèle de remplacement automatique.

## Lecture des résultats

`data/COUVERTURE.md` donne le nombre de contributions reçues, avec les jours manquants. Les fichiers `jour-N.json` indiquent le modèle demandé et retourné, l'identifiant API et le texte de chaque réponse acceptée. Une séance partielle peut contenir des erreurs. Le jour 7 contient les synthèses des modèles et leurs répliques. L'analyse indépendante doit citer les passages précis, distinguer accord et désaccord, relever les changements de position, vérifier les sources citées et qualifier l'effet des absences ou réponses tronquées.
